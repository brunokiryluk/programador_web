function homeController(){
    console.log('Se cargo la home')
  }
  
  export default homeController